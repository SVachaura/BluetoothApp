package com.bluetoothapp

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.*

class MainActivity : Activity() {
    private val blue = Color.rgb(23,105,255)
    private val pale = Color.rgb(237,244,255)
    private lateinit var root: LinearLayout
    private val adapter: BluetoothAdapter? by lazy {
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun tv(text:String, size:Float, color:Int=Color.rgb(17,24,39)): TextView =
        TextView(this).apply {
            this.text=text; textSize=size; setTextColor(color)
            setPadding(0,8,0,8)
        }

    private fun button(text:String, primary:Boolean=true, click:()->Unit): Button =
        Button(this).apply {
            this.text=text; textSize=15f; isAllCaps=false
            setTextColor(if(primary) Color.WHITE else Color.rgb(21,85,199))
            setBackgroundColor(if(primary) blue else pale)
            setOnClickListener { click() }
            val p=LinearLayout.LayoutParams(-1,58); p.setMargins(0,7,0,7); layoutParams=p
        }

    private fun base(): LinearLayout {
        root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(22,18,22,22)
            setBackgroundColor(Color.WHITE)
        }
        val scroll=ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        return root
    }

    private fun showHome() {
        base()
        root.addView(tv("BluetoothApp",29f,blue))
        root.addView(tv("● Bluetooth готов",13f,blue))

        root.addView(button("💬  Начать общение", true) { communication() }.apply {
            minHeight=92
            textSize=20f
            gravity=Gravity.CENTER_VERTICAL
        })
        root.addView(button("＋  Создать", false) {
            Toast.makeText(this,"Создание комнаты",Toast.LENGTH_SHORT).show()
            communication(create=true)
        })

        root.addView(tv("🎮  Игры от BluetoothApp",22f))
        root.addView(tv("Играй с ботом или с другом по Bluetooth.",14f,Color.GRAY))

        root.addView(button("❌⭕  Крестики-нолики\nБот или Bluetooth",false) { tttMenu() })
        root.addView(button("🃏  Дурак\nБот или Bluetooth",false) { durakMenu() })
    }

    private fun communication(create:Boolean=false) {
        base()
        root.addView(button("← Назад",false){showHome()})
        root.addView(tv("💬 Общение",25f))
        root.addView(tv("Общение по Bluetooth",14f,Color.GRAY))
        root.addView(button("🏠 Создать комнату",true){createRoom()})
        root.addView(button("🚪 Зайти в комнату",false){joinRoom()})
        if(create) createRoom()
    }

    private fun createRoom() {
        base()
        root.addView(button("← Назад",false){communication()})
        root.addView(tv("🏠 Создать комнату",25f))
        val name=EditText(this).apply { hint="Название комнаты"; setText("Моя комната"); textSize=16f }
        val pass=EditText(this).apply { hint="Пароль (необязательно)"; textSize=16f }
        root.addView(name); root.addView(pass)
        root.addView(button("Создать",true) {
            val n=name.text.toString().ifBlank{"Моя комната"}
            Toast.makeText(this,"Комната «$n» создана",Toast.LENGTH_LONG).show()
            requests(n)
        })
        root.addView(tv("Если пароль не задан, вход подтверждается владельцем.",13f,Color.GRAY))
    }

    private fun requests(room:String) {
        root.addView(tv("🔔 Запросы на вход",21f))
        root.addView(tv("Пока запросов нет. Когда кто-то захочет войти, здесь появятся кнопки «Принять» и «Не принять».",14f,Color.GRAY))
    }

    private fun joinRoom() {
        base()
        root.addView(button("← Назад",false){communication()})
        root.addView(tv("🚪 Зайти в комнату",25f))
        root.addView(tv("Комнаты рядом появятся здесь после поиска Bluetooth-устройств.",14f,Color.GRAY))
        root.addView(button("🔎 Найти комнаты",true){scanBluetooth()})
        root.addView(tv("Пример:",17f))
        roomCard("Комната Slava","2 участника · 🔒 пароль")
        roomCard("Комната Alex","1 участник · 🔓 без пароля")
    }

    private fun roomCard(name:String, info:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(10,8,10,8) }
        val text=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        text.addView(tv("🟦  $name",17f))
        text.addView(tv(info,13f,Color.GRAY))
        box.addView(text,LinearLayout.LayoutParams(0,-2,1f))
        val b=button("Войти",true) { passwordDialog(name, info.contains("🔒")) }
        b.layoutParams=LinearLayout.LayoutParams(110,58)
        box.addView(b)
        root.addView(box)
    }

    private fun passwordDialog(name:String, locked:Boolean) {
        if(!locked) {
            Toast.makeText(this,"Запрос отправлен владельцу комнаты",Toast.LENGTH_LONG).show()
            return
        }
        val input=EditText(this).apply { hint="Пароль" }
        AlertDialog.Builder(this).setTitle("Вход в комнату").setMessage(name)
            .setView(input).setNegativeButton("Отмена",null)
            .setPositiveButton("Отправить") { _,_ ->
                Toast.makeText(this,"Пароль отправлен. Ожидание подтверждения.",Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun scanBluetooth() {
        if(adapter==null){ Toast.makeText(this,"Bluetooth недоступен",Toast.LENGTH_SHORT).show(); return }
        if(android.os.Build.VERSION.SDK_INT>=31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT),44)
            return
        }
        adapter.startDiscovery()
        Toast.makeText(this,"Поиск Bluetooth-устройств…",Toast.LENGTH_LONG).show()
    }

    private fun tttMenu() {
        base(); root.addView(button("← Назад",false){showHome()})
        root.addView(tv("❌⭕ Крестики-нолики",25f))
        root.addView(button("🤖 Играть с ботом",true){tttGame()})
        root.addView(button("📡 Играть по Bluetooth",false){Toast.makeText(this,"Ожидание соперника…",Toast.LENGTH_LONG).show()})
    }

    private fun tttGame() {
        base(); root.addView(button("← Назад",false){tttMenu()})
        root.addView(tv("❌⭕ Крестики-нолики",25f))
        val board=Array(9){" "}
        val grid=GridLayout(this).apply { columnCount=3; rowCount=3 }
        val cells=Array(9){i->
            Button(this).apply {
                text=""; textSize=32f; setTextColor(blue)
                setOnClickListener {
                    if(text.isEmpty() && board[i]==" ") {
                        text="X"; board[i]="X"
                        if(win(board,"X")) { Toast.makeText(this@MainActivity,"Ты победил!",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                        botMove(board,cells)
                    }
                }
            }.also { grid.addView(it,GridLayout.LayoutParams().apply { width=0;height=120;columnSpec=GridLayout.spec(i%3,1f);rowSpec=GridLayout.spec(i/3,1f) }) }
        }
        root.addView(grid)
        root.addView(button("Новая игра",false){tttGame()})
    }

    private fun botMove(board:Array<String>, cells:Array<Button>) {
        val free=board.indices.filter{board[it]==" "}
        if(free.isEmpty()) return
        val i=free.random(); board[i]="O"; cells[i].text="O"
        if(win(board,"O")) Toast.makeText(this,"Бот победил!",Toast.LENGTH_SHORT).show()
    }

    private fun win(b:Array<String>,s:String):Boolean =
        listOf(intArrayOf(0,1,2),intArrayOf(3,4,5),intArrayOf(6,7,8),intArrayOf(0,3,6),intArrayOf(1,4,7),intArrayOf(2,5,8),intArrayOf(0,4,8),intArrayOf(2,4,6)).any{b[it[0]]==s&&b[it[1]]==s&&b[it[2]]==s}

    private fun durakMenu() {
        base(); root.addView(button("← Назад",false){showHome()})
        root.addView(tv("🃏 Дурак",25f))
        root.addView(tv("Первая версия режима.",14f,Color.GRAY))
        root.addView(button("🤖 Играть с ботом",true){durakBot()})
        root.addView(button("📡 Играть по Bluetooth",false){Toast.makeText(this,"Ожидание соперника…",Toast.LENGTH_LONG).show()})
    }

    private fun durakBot() {
        base(); root.addView(button("← Назад",false){durakMenu()})
        root.addView(tv("🃏 Дурак — против бота",25f))
        root.addView(tv("36-карточная колода · козырь · 2 игрока",14f,Color.GRAY))
        root.addView(tv("Козырь: ♠",20f,blue))
        root.addView(tv("Твои карты",18f))
        val cards=listOf("6♣","8♦","10♥","Q♠","A♣")
        cards.forEach { c ->
            root.addView(button(c,false){Toast.makeText(this,"Карта $c выбрана",Toast.LENGTH_SHORT).show()})
        }
        root.addView(button("Новая игра",true){durakBot()})
    }
}
